/**
 * ============================================================================
 * PROJECTE: dudeney (Step Quiz, vanilla JS)
 * FITXER: js/imprimir.js
 * ROL: Munta les fitxes per imprimir a partir de les mateixes dades i figures
 *   del web:
 *   - imprimir/enigmes.html (data-full="enigmes"): una portada amb l'índex i
 *     un full A4 per enigma (enunciat, figura, què cal fer i espai per pensar);
 *   - imprimir/solucions.html (data-full="solucions"): la solució de Dudeney,
 *     la seva figura i la nota del matemàtic de cada enigma.
 * ARQUITECTURA: Tot es dibuixa amb Taulers[t].figura / .figuraSolucio; el CSS
 *   d'impressió (css/imprimir.css) ho deixa en blanc i negre. El PDF el fa
 *   tools/genera-pdf.js.
 * DEPENDÈNCIES: js/comu/comu.js, js/comu/registre.js, les dades i els taulers.
 * ============================================================================
 */
(() => {
    'use strict';
    const C = window.Comu;
    const LLISTA = window.Dudeney.llista();
    const CREDIT =
        'Problemes de Henry E. Dudeney (1857–1930), d’obres de domini públic: The Canterbury Puzzles (1907) i Amusements in Mathematics (1917). Traducció, adaptació i figures: David Arso Civil (CC BY-NC-SA 4.0). dudeney.step-quiz.net';

    // El que cal fer en paper, i les opcions de la figura de cada enigma
    const PAPER = {
        amazones: { regla: 'Canvia de lloc tres reines (les pots posar a qualsevol casella) perquè quedin onze caselles que no ataqui cap reina. Marca amb un punt les caselles lliures.', extra: 'tauler' },
        presos: { regla: 'Fes-ho amb vuit papers numerats sobre una quadrícula de 3 × 3. Apunta el número de cada pres que mous. Quin pres no es mou mai?', linia: 'Els moviments:' },
        solitari: { regla: 'Fes-ho amb 32 fitxes o monedes sobre el dibuix ampliat. Apunta cada salt com Dudeney (per exemple, 19-17), amb parèntesis per als salts seguits de la mateixa fitxa.', linia: 'Els moviments:' },
        'nombres-curiosos': { regla: 'Busca els tres nombres més petits, després del 48, que fan que el nombre més 1 i la seva meitat més 1 siguin tots dos quadrats. Pots fer servir la calculadora.', linia: 'Els tres nombres:' },
        galetes: { regla: 'Escriu quantes galetes troba cada rodamón, quantes se’n menja i quantes en deixa. Quin és el nombre més petit de galetes que fa que tot surti exacte?', taula: ['Qui', 'troba', 'al gos', 'se’n menja', 'en deixa'], files: 5 },
        solda: { regla: 'Quin és el nombre més petit de soldats que es pot formar en dos quadrats de 12 maneres diferents? (Cada quadrat amb almenys un soldat; 81 + 49 i 49 + 81 són la mateixa manera.)', linia: 'Soldats:' },
        hastings: { regla: 'Busca el nombre y més petit tal que 61 · y² + 1 sigui un quadrat. (Una pista: la fracció contínua de √61 és [7; 1, 4, 3, 1, 2, 2, 1, 3, 4, 1, 14].)', linia: 'y = … i el total d’homes:' },
        trapezi: { regla: 'Retalla la figura en quatre peces exactament iguals: de la mateixa mida i de la mateixa forma.' },
        'cinc-triangles': { regla: 'Retalla cinc triangles com aquests (mig rectangle de 2 × 1) i fes-ne un quadrat. N’has de tallar un en dues peces; els altres, sencers.', figura: { paper: true } },
        fuster: { regla: 'Talla la fusta en el mínim de peces possible per fer el tauler quadrat, sense que en sobri gens. Quantes peces calen?', figura: { paper: true } },
        brocat: { regla: 'Retalla els dos quadrats només per les línies de la quadrícula, en quatre peces en total, i munta un quadrat de 10 × 10 amb les flors ben alternades. Dues peces han de tenir la mateixa àrea.' },
        mercer: { regla: 'Aquí tens les quatre peces de Dudeney: retalla-les i fes-ne un quadrat, sense girar-ne cap del revés. (Repte complet: dibuixa un triangle equilàter i busca tu els talls.)', figura: { peces: true } },
        granotes: { regla: 'Fes-ho amb sis monedes o papers numerats. Apunta l’ordre en què mous les granotes i compta els moviments.' },
        'granotes-gots': { regla: 'Fes-ho amb tres monedes d’un tipus i tres d’un altre sobre set llocs numerats. Apunta cada salt (d’on i cap on) i compta’ls: en calen deu.', linia: 'Els salts:' },
        twickenham: { regla: 'Fes-ho amb deu papers amb les lletres (cinc de clars i cinc de foscos) sobre onze llocs en cercle. Les foscos giren com les agulles del rellotge; les clares, al revés. Apunta les lletres que mous, per ordre: en calen vint-i-sis.', linia: 'Les lletres que mous:' },
        lletres: { regla: 'Fes-ho amb vuit papers amb lletres sobre una quadrícula de 3 × 3. Apunta les lletres que mous, per ordre. Quants moviments calen, com a mínim?', linia: 'Les lletres que mous:' },
        'quatre-granotes': { regla: 'Fes-ho amb dues monedes d’un tipus i dues d’un altre sobre el dibuix. Apunta cada jugada entre parèntesis, amb tots els moviments seguits d’una mateixa granota: en calen set.', linia: 'Les jugades:' },
        locomotores: { regla: 'Fes-ho amb vuit papers numerats sobre el dibuix. Apunta les locomotores que mous, per ordre: en calen disset. Quina no s’ha mogut?', linia: 'Les locomotores que mous:' },
        formatges: { regla: 'Fes-ho amb vuit monedes de mides diferents (o vuit papers numerats) i quatre llocs. Compta els moviments: quants en calen, com a mínim?' },
        rierol: { regla: 'Escriu cada travessia: qui va a la barca i cap a on. La barca no pot portar més de 150 lliures, i el gos (que en pesa 30) no sap remar.', taula: ['Travessia', 'A la barca', 'Cap a'], files: 12 },
        gerres: { regla: 'Escriu, després de cada abocada, quant vi hi ha a cada recipient. Cada vegada que vesses, el vi passa fins que l’un queda buit o l’altre ple.', taula: ['', 'gerra de 10', 'gerra de 10', 'mesura de 5', 'mesura de 4'], files: 12, primera: ['inici', '10', '10', '0', '0'] },
        bol: { regla: 'Escriu, després de cada manipulació, quanta llimonada hi ha al barril i a cada gerra, i quanta se n’ha begut cada rodamón. El que un rodamón s’ha begut ja no torna.', taula: ['', 'barril', 'gerra de 5', 'gerra de 3', 'X', 'Y', 'Z'], files: 12, primera: ['inici', '12', '0', '0', '0', '0', '0'] },
        tresor: { regla: 'Escriu cada manipulació: qui baixa i qui puja. Si a la cistella que baixa hi ha una persona, la diferència de pes no pot passar de 15 lliures; el tresor sol pot baixar amb qualsevol diferència.', linia: 'Les manipulacions (qui baixa i qui puja):' },
        entrenadors: { regla: 'Escriu cada travessia: qui va a la barca i cap a on. Hi caben tres persones, i cap estrella (minúscula) no pot estar amb un altre entrenador (majúscula) si el seu no hi és.', taula: ['Travessia', 'A la barca', 'Cap a'], files: 12 },
        alfils: { regla: 'Dibuixa alfils (punts o creus) perquè totes les caselles quedin ocupades o atacades. Recorda que un alfil no ataca a través d’una altra peça. Quants en calen, com a mínim?', figura: { cavalls: 'buit' } },
        'alfils-protegits': { regla: 'Dibuixa alfils perquè totes les caselles quedin ocupades o atacades i cada alfil estigui protegit per un altre. Quants en calen, com a mínim?', figura: { cavalls: 'buit' } },
        peons: { regla: 'Dibuixa els catorze peons que falten (setze amb els de d4 i e5): a cada fila i a cada columna n’hi ha d’haver dos, i mai tres en línia recta en cap direcció.' },
        reines: { regla: 'Busca una col·locació de vuit reines sense atacs i sense tres reines en línia en cap direcció. Dibuixa-la al tauler buit.', extra: 'tauler' },
        cavalls: { regla: 'Posa cavalls (punts o monedes) perquè totes les caselles quedin ocupades o atacades i cada cavall estigui protegit per un altre. Quants en calen, com a mínim?', figura: { cavalls: 'buit' } },
        ciutats: { regla: 'Dibuixa la ruta sobre el mapa: surt de l’1, passa una sola vegada per cada ciutat i torna a l’1. Quantes rutes hi ha?' },
        metro: { regla: 'Dibuixa la ruta sobre el plànol i escriu-la amb les lletres de les estacions. Quantes milles fa, com a mínim?', linia: 'Ruta:' },
        mina: { regla: 'Dibuixa la ruta sobre el plànol, sortint de la A, i escriu-la amb les lletres de les cruïlles. Quants furlongs fa, com a mínim?', linia: 'Ruta:' },
        mariner: { regla: 'Dibuixa la ruta sobre el mapa, sortint de la A, i escriu-la amb les lletres de les illes. Recorda que el mariner deixa la C per al més tard possible.', linia: 'Ruta:' },
        torre: { regla: 'Dibuixa el recorregut de la torre, sortint de d5: cada jugada és una línia recta per una fila o una columna, i cap casella no es pot repetir. Quantes jugades calen, com a mínim?' },
        octaedre: { regla: 'Dibuixa una ruta per les dotze arestes, sortint de la A i sense repetir-ne cap. Quantes rutes diferents hi ha?', linia: 'Ruta:' },
        vuit: { regla: 'Escriu nou nombres diferents perquè totes les files, columnes i diagonals sumin 15, amb el 8 al lloc on és.' },
        bachet: { regla: 'Escriu les setze cartes al quadrat (A, K, Q, J i ♦ ♠ ♥ ♣): cap fila, columna ni diagonal llarga pot repetir pal ni valor. De quantes maneres es pot fer?', figura: { cartes: new Array(16).fill(null) } },
        domino: { regla: 'Fes-ho amb un dòmino de veritat: tria divuit fitxes i posa-les de peu, com a la il·lustració, perquè totes les files, les columnes i les dues diagonals sumin 18.' },
        estripat: { regla: 'Busca un altre número de quatre xifres diferents que faci (primera meitat + segona meitat)² = el número.', linia: 'El número:' },
        amulet: { regla: 'Compta de quantes maneres es pot llegir ABRACADABRA, sortint de la A de dalt i baixant cada vegada a una de les dues lletres que hi ha a sota.', linia: 'Resposta:' },
        rectangles: { regla: 'Compta quants rectangles (quadrats inclosos) té el tauler d’escacs, i quants d’aquests rectangles són quadrats.', linia: 'Respostes:' },
        aranya: { regla: 'Dibuixa la sala desplegada com una capsa de cartró i traça-hi el camí recte de l’aranya. Quin és el camí més curt?' },
        creus: { regla: 'Retalla la creu en cinc peces: una ha de ser una creu sencera més petita, i amb les altres quatre (sense girar-les del revés) n’has de fer una altra d’igual. Pista: la creu petita va una mica girada.', figura: { paper: true } },
        mitra: { regla: 'Retalla la mitra (un quadrat sense una quarta part) en cinc peces i fes-ne un quadrat perfecte. Compte: el «principi de l’escala» no hi funciona.', figura: { paper: true } },
        cent: { regla: 'Escriu 100 com a nombre mixt (un enter més una fracció) amb les nou xifres de l’1 al 9, una vegada cadascuna, amb una sola xifra a la part entera. Exemple, amb dues: 91 + 5742/638.', linia: 'Les teves maneres:' },
        multiplicacio: { regla: 'Escriu dues multiplicacions amb el mateix producte fent servir les nou xifres una vegada cadascuna, com 7 × 658 = 14 × 329 = 4606. Busca el producte amb la suma de xifres més petita i el de la suma més gran.', linia: 'Producte més petit i més gran:' },
        bandolers: { regla: 'Busca quants repartiments de 200 doblons entre els cinc bandolers (tots en tenen almenys un) fan encara 200 amb A × 12, B × 3, C × 1, D × ½ i E × ⅓, sense mitjos doblons. Fes-ho per casos.', linia: 'Resposta:' },
        prunes: { regla: 'Escriu nou nombres diferents al quadrat perquè totes les files, columnes i diagonals sumin el mateix, i cap no es pugui repartir a parts iguals entre uns quants nens (cap divisor que no sigui 1 o ell mateix). Compte amb el parany!' },
        compostos: { regla: 'Escriu nou nombres compostos consecutius (sense cap primer al mig), els més petits possible, en un quadrat màgic de 3 × 3.' },
        reversible: { regla: 'Escriu setze nombres diferents (sense les xifres 3, 4 i 5) en un quadrat màgic de 4 × 4 que continuï sent màgic quan gires el full cap per avall. El 6 i el 9 s’intercanvien, i el 7 i el 2 també.' },
    };

    function textNet(html) {
        const caixa = C.el('div', { html });
        caixa.querySelectorAll('.pantalla').forEach(e => e.remove());
        return caixa;
    }
    function notesUnitats(caixa) {
        const notes = [...new Set([...caixa.querySelectorAll('.unitat[data-nota]')].map(e => e.dataset.nota))];
        return notes.length ? C.el('p', { class: 'notes-unitats', text: 'Unitats: ' + notes.join('; ') + '.' }) : null;
    }
    function figura(p, opcions) {
        const T = window.Taulers[p.tauler];
        const f = T.figura(p, opcions || {});
        return C.el('div', { class: 'figura-full' }, f);
    }

    function fullPortada(titol, entrada) {
        const s = C.el('section', { class: 'full portada-full' });
        s.append(
            C.el('div', { class: 'cap-full' }, C.el('span', { text: 'Step Quiz · dudeney.step-quiz.net' }), C.el('span', { text: `${LLISTA.length} enigmes` })),
            C.el('h1', { text: titol }),
            C.el('p', { class: 'entrada', text: entrada })
        );
        // L'índex, en dues columnes quan els enigmes no hi caben en una
        const columnes = LLISTA.length > 28 ? 2 : 1;
        const porColumna = Math.ceil(LLISTA.length / columnes);
        const index = C.el('div', { class: 'index-columnes c' + columnes });
        for (let k = 0; k < columnes; k++) {
            const taula = C.el('table', { class: 'index-enigmes' });
            LLISTA.slice(k * porColumna, (k + 1) * porColumna).forEach((p, j) => {
                const i = k * porColumna + j;
                taula.appendChild(
                    C.el('tr', null, C.el('td', { text: i + 1 }), C.el('td', { text: p.titol }), C.el('td', { text: columnes > 1 ? `${C.TIPUS[p.tipus].nom} · ${p.dificultat}/3` : C.TIPUS[p.tipus].nom + ' · dificultat ' + p.dificultat + ' de 3' }))
                );
            });
            index.appendChild(taula);
        }
        s.append(index, C.el('p', { class: 'peu-full', text: CREDIT }));
        return s;
    }

    function fullEnigma(p, i) {
        const o = PAPER[p.id] || {};
        const s = C.el('section', { 'class': 'full', 'data-id': p.id });
        const llibre = C.LLIBRES[p.font.llibre];
        s.append(
            C.el('div', { class: 'cap-full' }, C.el('span', { text: `Enigma ${i + 1} de ${LLISTA.length}` }), C.el('span', { class: 'tipus', text: `${C.TIPUS[p.tipus].nom} · dificultat ${p.dificultat} de 3` })),
            C.el('h1', { text: p.titol }),
            C.el('p', { class: 'original', text: `${p.font.titolOriginal}, ${llibre.titol} (${llibre.any}), núm. ${p.font.numero}` })
        );
        const text = textNet(p.enunciat.join(''));
        text.className = 'text-full';
        s.appendChild(text);
        const notes = notesUnitats(text);
        if (notes) s.appendChild(notes);
        const fig = figura(p, o.figura || p.figuraEnunciat);
        if (o.extra === 'tauler') {
            // al costat de la figura de Dudeney, un tauler buit per dibuixar-hi
            fig.classList.add('dues');
            fig.appendChild(window.Taulers.cavalls.figura(window.Dudeney.perId('cavalls'), { cavalls: 'buit' }));
        }
        s.appendChild(fig);
        if (o.regla) s.appendChild(C.el('p', { class: 'regla-full', text: o.regla }));
        if (o.taula) {
            const t = C.el('table', { class: 'taula-buida' });
            t.appendChild(C.el('tr', null, o.taula.map(h => C.el('th', { text: h }))));
            for (let k = 0; k < o.files; k++) {
                const fila = k === 0 && o.primera ? o.primera : o.taula.map((h, j) => (j === 0 && o.taula[0] === 'Travessia' ? String(k + 1) : j === 0 && !h ? String(k) : ''));
                t.appendChild(C.el('tr', null, fila.map(x => C.el('td', { text: x }))));
            }
            s.appendChild(t);
        }
        s.appendChild(C.el('div', { 'class': 'espai', 'data-text': o.linia || 'Espai per pensar-hi' }));
        s.appendChild(C.el('p', { class: 'peu-full', text: CREDIT }));
        return s;
    }

    function fullSolucio(p, i) {
        const s = C.el('section', { 'class': 'solucio-full', 'data-id': p.id });
        s.append(
            C.el('div', { class: 'cap-full' }, C.el('span', { text: `Solució de l’enigma ${i + 1}` }), C.el('span', { class: 'tipus', text: C.TIPUS[p.tipus].nom })),
            C.el('h1', { text: p.titol }),
            C.el('h2', { text: 'La solució de Dudeney' })
        );
        const t = C.el('div', { class: 'text', html: p.solucioDudeney.join('') });
        const T = window.Taulers[p.tauler];
        let fig = null;
        if (T.figuraSolucio) fig = T.figuraSolucio(p);
        else if (p.tauler === 'salts')
            fig = C.el(
                'figure',
                null,
                T.figura(p, { estat: p.dades.final || [0, 6, 5, 4, 3, 2, 1] }),
                C.el('figcaption', { text: p.dades.peuFinal || 'Al final: 6, 5, 4, 3, 2, 1.' })
            );
        if (fig) t.insertBefore(fig, t.children[p.posicioFiguraSolucio || 1] || null);
        s.appendChild(t);
        s.append(C.el('h2', { text: 'Nota del matemàtic' }), C.el('div', { class: 'text', html: p.notaMatematic.join('') }));
        s.appendChild(C.el('p', { class: 'peu-full', text: CREDIT }));
        return s;
    }

    const cos = document.body;
    document.querySelectorAll('.nomes-amb-solucions').forEach(e => (e.hidden = !C.ambSolucions()));
    C.propagaSolucions();
    // Les solucions només es mostren amb ?sol=1 (el PDF les genera amb aquest paràmetre)
    if (cos.dataset.full === 'solucions' && !C.ambSolucions()) {
        cos.appendChild(C.el('section', { class: 'solucio-full' }, C.el('h1', { text: 'Les solucions no són públiques' }), C.el('p', { text: 'Demana-les al teu professor o professora.' })));
        return;
    }
    if (cos.dataset.full === 'enigmes') {
        cos.appendChild(fullPortada('Els enigmes de Dudeney', `${LLISTA.length} trencaclosques de Henry E. Dudeney, el gran inventor d’enigmes anglès, traduïts al català, de set tipus diferents. Un enigma per full, amb espai per pensar-hi. Les solucions són en un altre document. A la pantalla s’hi pot jugar a dudeney.step-quiz.net.`));
        LLISTA.forEach((p, i) => cos.appendChild(fullEnigma(p, i)));
    } else {
        LLISTA.forEach((p, i) => cos.appendChild(fullSolucio(p, i)));
    }
    document.querySelectorAll('[data-imprimeix]').forEach(b => b.addEventListener('click', () => window.print()));
})();
